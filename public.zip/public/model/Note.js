export class Note {
    constructor({ id = null, taskId = null, content = '', createdAt = new Date().toISOString(), updatedAt = new Date().toISOString() }) {
      this.id = id;
      this.taskId = taskId;
      this.content = content;
      this.createdAt = createdAt;
      this.updatedAt = updatedAt;
    }
  
    static fromFirestore(doc) {
      const data = doc.data();
      return new Note({ id: doc.id, ...data });
    }
  
    toFirestore() {
      return {
        taskId: this.taskId,
        content: this.content,
        createdAt: this.createdAt,
        updatedAt: new Date().toISOString(),
      };
    }
  
    updateNote(newContent) {
      this.content = newContent;
      this.updatedAt = new Date().toISOString();
    }
  }
  