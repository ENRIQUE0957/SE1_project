export const root = document.getElementById('root');
export const userInfo = document.getElementById('userInfo');